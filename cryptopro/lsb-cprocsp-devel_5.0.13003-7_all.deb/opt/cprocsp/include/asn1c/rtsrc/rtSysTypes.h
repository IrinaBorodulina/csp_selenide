/*
 * Copyright (C) 1997-2003 by Objective Systems, Inc.
 *
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the
 * inclusion of the above copyright notice. This software or any other
 * copies thereof may not be provided or otherwise made available to any
 * other person. No title to and ownership of the software is hereby
 * transferred.
 *
 * The information in this software is subject to change without notice
 * and should not be construed as a commitment by Objective Systems, Inc.
 *
 * PROPRIETARY NOTICE
 *
 * This software is an unpublished work subject to a confidentiality agreement
 * and is protected by copyright and trade secret law.  Unauthorized copying,
 * redistribution or other use of this work is prohibited.
 *
 * The above notice of copyright on this source code product does not indicate
 * any actual or intended publication of such source code.
 *
 *****************************************************************************/

// standard types include file

/**
 * @file rtSysTypes.h
 */

#ifndef _RTSYSTYPES_H_
#define _RTSYSTYPES_H_

#ifndef FALSE
#define FALSE   0
#define TRUE    !FALSE
#endif

#define NumberOf(x)	(sizeof(x)/sizeof(x[0]))

typedef void            OSVoid;
typedef void*           OSVoidPtr;
typedef unsigned char   OSBOOL;
typedef char            OSINT8;
typedef unsigned char   OSUINT8;
typedef short           OSINT16;
typedef unsigned short  OSUINT16;
typedef int             OSINT32;
typedef unsigned int    OSUINT32;
typedef OSUINT8		OSOCTET;
typedef OSUINT8         OSUTF8CHAR;
typedef OSUINT16        OSUNICHAR;

#endif
