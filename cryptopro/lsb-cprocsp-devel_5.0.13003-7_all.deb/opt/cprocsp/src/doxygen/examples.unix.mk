.SUFFIXES: .cpp

#CPCCC=$(CCC)
CPCCC=$(CXX)

SAN_FLAGS=
#SAN_FLAGS=-fsanitize=address
#SAN_FLAGS=-fsanitize=thread
#SAN_FLAGS=-fsanitize=undefined

CFLAGS=-DUNIX -DHAVE_LIMITS_H $(ARCH_FLAGS) $(add_CPPFLAGS) -I$(CSP_INCLUDE) -I$(CSP_INCLUDE)/cpcsp -I$(CSP_INCLUDE)/asn1c/rtsrc -I$(CSP_INCLUDE)/asn1data -DSIZEOF_VOID_P=$(SIZEOF_VOID_P) -g $(SAN_FLAGS)

ORD_FLAGS=$(ARCH_FLAGS) -L$(CSP_LIB) -lssp -lcapi10 -lcapi20 -lrdrsup $(CSP_EXTRA_LIBS) $(add_ldflags) -g

# For FreeBSD you should add -pthread to LDFLAGS.
#FBSD_FLAGS=-pthread

LDFLAGS=$(ORD_FLAGS) $(FBSD_FLAGS) $(SAN_FLAGS)

OBJS=$(out).o
$(out): $(OBJS)
	$(CPCCC) $(OBJS) $(LDFLAGS) -o $@ $(add_libs)
clean:
	for i in $(out) $(OBJS) ; do test -r "$${i}" || continue ; rm "$${i}" ; done
.cpp.o:
	$(CPCCC) $(CFLAGS) -c -o $@ $<
