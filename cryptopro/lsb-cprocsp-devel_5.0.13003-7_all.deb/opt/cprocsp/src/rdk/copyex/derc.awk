# states:
# 1 - inside VS_VERSION_INFO
BEGIN{
	n=1
	hexarr["0"]=0
	hexarr["1"]=1
	hexarr["2"]=2
	hexarr["3"]=3
	hexarr["4"]=4
	hexarr["5"]=5
	hexarr["6"]=6
	hexarr["7"]=7
	hexarr["8"]=8
	hexarr["9"]=9
	hexarr["a"]=10
	hexarr["A"]=10
	hexarr["b"]=11
	hexarr["B"]=11
	hexarr["c"]=12
	hexarr["C"]=12
	hexarr["d"]=13
	hexarr["D"]=13
	hexarr["e"]=14
	hexarr["E"]=14
	hexarr["F"]=15
	hexarr["f"]=15
}
/^[ \t]*LANGUAGE[ \t]*LANG_RUSSIAN/{lang=0}
/^[ \t]*LANGUAGE[ \t]*LANG_ENGLISH/{lang=1}
/^[ \t]*BLOCK[ \t]*"080004b0/{lang=0}
/^[ \t]*BLOCK[ \t]*"040904[bB]0/{lang=0}
/^[ \t]*BLOCK[ \t]*"041904[bB]0/{lang=1}
/^[ \t]*FILEVERSION/{
  ind=index($0,"FILEVERSION")+12
  str=substr($0,ind,length()+1-ind)
#  ind=match(str,"[^ \t]")
#  version=substr(str,ind,length(str)+1-ind)
  version=str;
}
/^[ \t]*STRINGTABLE/{
  state=0
  FS=" "
  getline
  if($0 ~ /^[ \t]*BEGIN/) getline;
  while($0 !~ /^[ \t]*END/){
    number=to_dec($1)
    if (number == "")
	exit 1
    if (numbers[number] == "") {
	new_numbers[n++]=number;
    } 
#    numbers[number]=number;
    while($0 !~ /"/) getline; # if the value begins on next line
    o_ind=index($0,"\"")
    str=substr($0,o_ind,length()+1-o_ind)
    if(!length(numbers[number])) numbers[number]="nn";
    if(lang==0){
      strings_ru[number]=str;
      numbers[number]="r" substr(numbers[number],2,1) number
    }else{
      strings_en[number]=str;
      numbers[number]=substr(numbers[number],1,1) "e" number
    }
    getline
  }
}
/^[ \t]*VS_VERSION_INFO/{state=1;FS=","}
/^[ \t]*VALUE[ \t]*"CompanyName"/ && (state==1){
  v_info_cn[lang]=$2
}
/^[ \t]*VALUE[ \t]*"LegalCopyright"/ && (state==1){
  for(i=1;i<=split($2,arr,"\" *\"");i++) v_info_lc[lang]=v_info_lc[lang] arr[i]
}
    
END{
# need to sort as we search with bsearch later on

  shit_sort(new_numbers)
  if (po == "") {
      print "/*! ���������� ������� �����. */";
      print "#if defined(CSP_LITE) || !defined(USE_NLCAT)"
      print "static const TSupStringTableItem "prefix"_STRING_TABLE[] ="
      print "{"
  } else {
      print "$quote \""
      print "$set 1"
  }
  for(i=1;i<n;i++){
    cur=new_numbers[i]
    cur_str=numbers[cur]
    # No (var in array) in some versions of awk, although is in manual
    # Must die, so i have to f*ck with arrays
    if(substr(cur_str,3,length(cur_str)-2)!=cur) continue;
    if (po == "") {

    print "  {"
	printf "    0x%x,\n", cur
	if(substr(cur_str,1,2)=="re"){
	  print "    _LANGTEXT("
	  print "      " strings_en[cur] ","
	  print "      " strings_ru[cur]
	  print "    )"
	}else{
	  if(substr(cur_str,1,1)=="r")
	    print "(const wchar_t*)    L" strings_ru[cur]
	  else
	    print "(const wchar_t*)    L" strings_en[cur]
	}
	print "  },"
    } else {
	if (po == "ru" && substr(cur_str,1,1) == "r" ) {
		out=strings_ru[cur]
	} else if (po == "en" && (substr(cur_str,1,2) == "re" || substr(cur_str,1,1) == "e")) {
		out=strings_en[cur]
	}
	gsub("\"\"","\\\"",out)
        printf "%d %s\n", cur, out
    }
  }
  if (po == "")
  {
      if(v_info_cn[0]=="") v_info_cn[0]="\"UNDEFINED\""
      if(v_info_cn[1]=="") v_info_cn[1]="\"UNDEFINED\""
      if(v_info_lc[0]=="") v_info_lc[0]="\"UNDEFINED\""
      if(v_info_lc[1]=="") v_info_lc[1]="\"UNDEFINED\""
      if(version == "") version="0,0,0,0"
      print "};"
      print "#endif\n"
      print "/*! ���������� ������� ������. */"

      print "static const TSupVersionItem "prefix"_VERSION ="
      print "{"
      print "  _LANGTEXT("
      print "    " v_info_cn[0] ","
      print "    " v_info_cn[1]
      print "  ),"
      print "  _LANGTEXT("
      print "    " v_info_lc[0] ","
      print "    " v_info_lc[1]
      print "  ),"
      print "  {" version " } "
      print "};"
      print "#if !defined(CSP_LITE) && defined(USE_NLCAT)"
      print "static void "prefix"_once_init(void);"
      print "static TSupInstanceCatalog "prefix"_catalog = "
      print "{"
      print "  PTHREAD_ONCE_INIT,"
      print "  "prefix"_once_init,"
      print "  PTHREAD_MUTEX_INITIALIZER,"                 
      print "  (nl_catd)(-1)"
      print "};"  
      print "#endif"
      print "static TSupInstanceResourceDecl "prefix"_RESOURCE_TABLE ="
      print "{"
      print "#if !defined(CSP_LITE) && defined(USE_NLCAT)"
      print "  &"prefix"_catalog,"
      print "#else"
      print "  sizeof("prefix"_STRING_TABLE) / sizeof( TSupStringTableItem ),"
      print "  "prefix"_STRING_TABLE,"
      print "#endif"
      print "  &"prefix"_VERSION,"
      print "  0, 0"
      print "};"
      print "#ifndef CSP_LITE"
      print "#ifdef USE_NLCAT"
      print "#ifndef FREEBSD"
      print "#define CATNAME \""catname".cat\""
      print "#else"
      print "#define CATNAME \""catname"\""
      print "#endif //FREEBSD"
      print "static void "prefix"_once_init(void)"
      print "{"
      print "   const char * cur_lang=setlocale(LC_MESSAGES,NULL);"
      print "   support_init_locale();"
      print "#ifdef SOLARIS"
      print "   "prefix"_RESOURCE_TABLE.catalog->nl_id=(nl_catd)(-1);"
      print "   if (cur_lang==NULL || strcmp(cur_lang,\"C\") != 0)"
      print "       "prefix"_RESOURCE_TABLE.catalog->nl_id=catopen(CATNAME,NL_CAT_LOCALE);"
      print "#else "
      print "   "prefix"_RESOURCE_TABLE.catalog->nl_id=catopen(CATNAME,NL_CAT_LOCALE);"
      print "#endif //SOLARIS"
      print "   if ("prefix"_RESOURCE_TABLE.catalog->nl_id == (nl_catd)(-1))"
      print "   {"
      print "	    char buf[PATH_MAX]; "
      print "	    sprintf(buf,\"%s/../../%s/"catname".cat\", CSP_DEF_LDIR, cur_lang); "
      print "	    "prefix"_RESOURCE_TABLE.catalog->nl_id=catopen(buf, NL_CAT_LOCALE);"
      print "       if ("prefix"_RESOURCE_TABLE.catalog->nl_id != (nl_catd)(-1))"
      print "           return;"
      print "       sprintf(buf, \"%s/../../%s/LC_MESSAGES/"catname".cat\", CSP_DEF_LDIR, cur_lang); "
      print "       "prefix"_RESOURCE_TABLE.catalog->nl_id=catopen(buf, NL_CAT_LOCALE);"
      print "       if ("prefix"_RESOURCE_TABLE.catalog->nl_id != (nl_catd)(-1))"
      print "           return;"
      print "       sprintf(buf, \"%s/"catname".cat\", CSP_DEF_LDIR); "
      print "       "prefix"_RESOURCE_TABLE.catalog->nl_id=catopen(buf, NL_CAT_LOCALE);"
      print "   }"
      print "}"
      print "#endif //USE_NLCAT"
      print "#endif //CSP_LITE"
      print "const TSupInstanceResourceDecl * "prefix"_RESOURCE = &"prefix"_RESOURCE_TABLE;\n"
      print "#endif /* !defined( _RESOURCE ) */"
      print "/* end of file */"
   }
}
#bubble sort - enough for us as the number of constats is small
function shit_sort(a,i,c,v,n) {
	
	for (n=1;a[n]!="";n++);
	n--;
	do {
		c=0;
		for (i=1;i<n;i++) 
			if (a[i+1]<a[i]) {
				v=a[i+1]
				a[i+1]=a[i]
				a[i]=v
				c=1
			}
	} while (c==1)
}
# convert a number to it's digital value
# rerurn value:
# if the number is hexadecimal or decimal - the decimal value
# "" if the string is neither hexadecimal nor decimal value
function to_dec(a,i,c,d,s) {
	d=0
	s=0
	d=substr(a,1,1)
	if (d=="" || d<"0" || d>"9")
		return ""
	if (substr(a,1,2)=="0x" || substr(a,1,2)=="0X") {
		for (i=3;(c=substr(a,i,1))!="";i++){
			if ((d=hexarr[c])=="")
				return ""
			s=s*16+d
		}
		return s
	} else {
		for (i=2;(c=substr(a,i,1))!="";i++) {
			if (c<"0" || c>"9")
				return ""
		}	
		return a
	}
}

