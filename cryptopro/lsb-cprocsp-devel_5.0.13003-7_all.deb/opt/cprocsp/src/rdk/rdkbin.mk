include /opt/cprocsp/src/rdk/rdkcommon.mk

SAN_FLAGS=
#SAN_FLAGS+=-fsanitize=address
#SAN_FLAGS+=-fsanitize=thread
#SAN_FLAGS+=-fsanitize=undefined

LDFLAGS+=-L$(CSP_LIB) -lrdrsup $(add_ldflags) -g $(SAN_FLAGS)
#LDFLAGS+=-lpthread
#LDFLAGS+=-R$(CSP_LIB)
CPPFLAGS+=$(add_cppflags)
CFLAGS+=$(add_cflags) $(SAN_FLAGS)
CXXFLAGS+=$(add_cxxflags) $(SAN_FLAGS)

$(out): $(OBJS)
	$(CPCCC) $(OBJS) -o $@ $(add_libs) $(LDFLAGS)
clean:
	for i in $(out) $(OBJS) $(lang_DATA) $(BUILT_SOURCES) cpp.out rc_tmp.c err.out *.msg; do test -r "$${i}" || continue ; rm "$${i}" ; done

install:
