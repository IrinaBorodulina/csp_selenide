.SUFFIXES: .cpp .c

#CPCCC=$(CCC)
#CPCCC=$(CXX)
#CPCCC=$(CXX)
CPCCC=$(CXX)
#CPCCC=$(CCC)

#aix_CPPFLAGS=-DAIX -DHAVE_STRNLEN -DHAVE_WCSNLEN
#aix_LDFLAGS=-brtl

#freebsd_CPPFLAGS=-DFREEBSD -DHAVE_STRNLEN -DHAVE_WCSNLEN

linux_CPPFLAGS=-DLINUX -DHAVE_STRNLEN -DHAVE_WCSNLEN

#solaris_CPPFLAGS=-DSOLARIS
#solaris_CXXFLAGS=-features=extensions

#wbe_CPPFLAGS=-DWORDS_BIGENDIAN

#SAN_FLAGS=-fsanitize=address
#SAN_FLAGS=-fsanitize=thread
#SAN_FLAGS=-fsanitize=undefined

locale_CPPFLAGS=-DUSE_NLCAT

CPPFLAGS=-DUNIX -DHAVE_LIMITS_H $(add_CPPFLAGS) -I$(CSP_INCLUDE) -I$(CSP_INCLUDE)/cpcsp -I$(CSP_INCLUDE)/reader -I$(CSP_INCLUDE)/asn1c/rtsrc -I$(CSP_INCLUDE)/asn1data_XER -I$(CSP_DIR)/src/rdk/include -I$(CSP_DIR)/src/rdk/include/reader -DSIZEOF_VOID_P=$(SIZEOF_VOID_P) -g $(aix_CPPFLAGS) $(freebsd_CPPFLAGS) $(linux_CPPFLAGS) $(solaris_CPPFLAGS) $(wbe_CPPFLAGS) $(locale_CPPFLAGS)

CFLAGS=$(ARCH_FLAGS) $(SAN_FLAGS)
CXXFLAGS=$(ARCH_FLAGS) $(SAN_FLAGS) $(solaris_CXXFLAGS)

LDFLAGS=$(SAN_FLAGS) $(ARCH_LDFLAGS)

VPATH=/opt/cprocsp/src/rdk:$(add_vpath)

.cpp.o:
	$(CPCCC) $(CPPFLAGS) $(CXXFLAGS) -c -o $@ $<
.c.o:
	$(CC) $(CPPFLAGS) $(CFLAGS) -c -o $@ $<
