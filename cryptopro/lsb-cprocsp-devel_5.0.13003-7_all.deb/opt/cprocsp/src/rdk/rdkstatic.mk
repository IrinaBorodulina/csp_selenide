include /opt/cprocsp/src/rdk/rdkcommon.mk

CPPFLAGS+=$(add_cppflags)
CFLAGS+=$(add_cflags)
CXXFLAGS+=$(add_cxxflags)

$(out): $(OBJS)
	ar cru $(out) $(OBJS)
	ranlib $(out)
clean:
	for i in $(out) $(OBJS) $(lang_DATA) $(BUILT_SOURCES) cpp.out rc_tmp.c err.out *.msg; do test -r "$${i}" || continue ; rm "$${i}" ; done

install:
