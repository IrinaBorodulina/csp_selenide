include /opt/cprocsp/src/rdk/rdkcommon.mk

LDFLAGS+=$(RDK_EXTRA_LIBS) -L$(CSP_LIB) -lrdrsup $(add_ldflags) -g

#LDFLAGS+=-G
#CFLAGS+=-fPIC -DPIC
#CXXFLAGS+=-fPIC -DPIC
#LDFLAGS+=-shared 
#CFLAGS+=-fPIC -DPIC
#CXXFLAGS+=-fPIC -DPIC
#LDFLAGS+=-shared -Wl,--rpath -Wl,$(CSP_LIB) -Wl,-soname -Wl,$(out).so.4 
CFLAGS+=-fPIC -DPIC
CXXFLAGS+=-fPIC -DPIC
LDFLAGS+=-shared -Wl,--rpath -Wl,$(CSP_LIB) -Wl,--dynamic-linker=$(LSB_LD) -Wl,-soname -Wl,$(out).so.4 
#CFLAGS+=-KPIC -DPIC
#CXXFLAGS+=-KPIC -DPIC
#LDFLAGS+=-G -h$(out).so.4 -R$(CSP_LIB)

CPPFLAGS+=$(add_cppflags)
CFLAGS+=$(add_cflags)
CXXFLAGS+=$(add_cxxflags)

$(out).so.4.0.5: $(OBJS)
	$(CPCCC) $(OBJS) -o $@ $(add_libs) $(LDFLAGS)
$(out).so.4 $(out).so: $(out).so.4.0.5
	ln -sf $(out).so.4.0.5 $(out).so.4
	ln -sf $(out).so.4.0.5 $(out).so
clean:
	for i in $(out).so* $(OBJS) $(lang_DATA) $(BUILT_SOURCES) cpp.out rc_tmp.c err.out *.msg; do test -r "$${i}" || continue ; rm "$${i}" ; done
install:
	mkdir -p $(DESTDIR)$(CSP_LIB)
	mkdir -p $(DESTDIR)/opt/cprocsp/share/locale/default/LC_MESSAGES
	mkdir -p $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.cp1251/LC_MESSAGES
	mkdir -p $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.iso88595/LC_MESSAGES
	mkdir -p $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.koi8r/LC_MESSAGES
	mkdir -p $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.cp866/LC_MESSAGES
	mkdir -p $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.utf8/LC_MESSAGES
	$(INSTALL) $(out).so.4.0.5 $(DESTDIR)$(CSP_LIB) 
	(cd $(DESTDIR)$(CSP_LIB);ln -sf $(out).so.4.0.5 $(out).so.4;ln -sf $(out).so.4.0.5 $(out).so)
	$(INSTALL) $(out).cat $(DESTDIR)/opt/cprocsp/share/locale/default/LC_MESSAGES
	$(INSTALL) $(out)_cp1251.cat $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.cp1251/LC_MESSAGES/$(out).cat
	$(INSTALL) $(out)_iso8859-5.cat $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.iso88595/LC_MESSAGES/$(out).cat
	$(INSTALL) $(out)_koi8-r.cat $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.koi8r/LC_MESSAGES/$(out).cat
	$(INSTALL) $(out)_cp866.cat $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.cp866/LC_MESSAGES/$(out).cat
	$(INSTALL) $(out)_utf-8.cat $(DESTDIR)/opt/cprocsp/share/locale/ru_RU.utf8/LC_MESSAGES/$(out).cat
