<?xml version="1.0" encoding="windows-1251"?>
 <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
 		xmlns:fo="http://www.w3.org/1999/XSL/Format"
 		version='1.0'>



<xsl:template match="TimeStampAuthenticodeRequest" name="TimeStampAuthenticodeRequest">


	
    <!-- Header ��������� �������� -->

  <fo:static-content flow-name="xsl-region-before">
    <fo:block>
    </fo:block>
  </fo:static-content>



      <!-- Footer ��������-->

  <fo:static-content flow-name="xsl-region-after">
    <fo:block text-align="center" font-size="10pt" 	
	      >
      <xsl:call-template name="printTEXT"> <xsl:with-param name="textID">local_paper</xsl:with-param> </xsl:call-template>			<!-- ����� -->
      <fo:page-number/>
      <xsl:call-template name="printTEXT"> <xsl:with-param name="textID">local_of</xsl:with-param> </xsl:call-template>
      <fo:page-number-citation ref-id="end of certificate"/>
    </fo:block>
  </fo:static-content>





	<!-- ������ ����������� -->

		<!-- ��������� ����� �������-->

  <fo:flow flow-name="xsl-region-body">


    <fo:block font-family="Arial" font-size="14pt"
	      text-align="center"
	      space-before="32pt"
	      space-after="16pt"
	      space-before.precedence="0"
	      space-after.precedence="3"                
	      keep-with-next="always"
	      >  
	      <xsl:call-template name="printTEXT"> <xsl:with-param name="textID">local_TimeStampAuthenticodeRequest_header</xsl:with-param> </xsl:call-template>
    </fo:block>


            <!-- ������ �������� ��������������� ������ -->	  
    <xsl:call-template name="uc_title"/>


    <fo:block font-family="Times" font-size="10pt"
	      space-before="4pt"
	      space-after="2pt"
	      space-before.precedence="0"
	      space-after.precedence="3"                
	      keep-with-next="always"
	      >  
	      <xsl:call-template name="printTEXT"> <xsl:with-param name="textID">local_TimeStampAuthenticodeRequest_timeStampAlgorithm</xsl:with-param> </xsl:call-template>
    </fo:block>

      <xsl:for-each select="./timeStampAlgorithm">  
	<xsl:call-template name="printOID"/>
      </xsl:for-each>

      <xsl:for-each select="./contentInfo">  
	<xsl:call-template name="ContentInfo"/>
      </xsl:for-each>


      <xsl:for-each select="./attributes">  
	<xsl:call-template name="UnsignedAttributes"/>
      </xsl:for-each>


    <fo:block id="end of certificate">
    </fo:block>
  </fo:flow>



</xsl:template>



</xsl:stylesheet>
