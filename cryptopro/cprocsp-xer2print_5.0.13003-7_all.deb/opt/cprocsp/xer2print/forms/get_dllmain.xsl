<?xml version="1.0" encoding="windows-1251"?>

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
		xmlns:msxsl="urn:schemas-microsoft-com:xslt"
		xmlns:cp="localhost"
		xmlns:fo="http://www.w3.org/1999/XSL/Format"
		version='1.0'>


<xsl:template match="/">

<xsl:element name="xsl:stylesheet">
	<xsl:copy-of select="document('main.xsl')/xsl:stylesheet/@*" />
	<!--xsl:attribute name="xmlns:xsl">http://www.w3.org/1999/XSL/Transform</xsl:attribute>
	<xsl:attribute name="xmlns:msxsl">urn:schemas-microsoft-com:xslt"</xsl:attribute>
	<xsl:attribute name="xmlns:cp">localhost"</xsl:attribute>
	<xsl:attribute name="xmlns:fo">http://www.w3.org/1999/XSL/Format</xsl:attribute>
	<xsl:attribute name="version">1.0</xsl:attribute-->


<xsl:copy-of select="document('variables.xsl')/xsl:stylesheet/*"/>
	
<xsl:element name="xsl:variable">
	<xsl:attribute name ="name">local_file</xsl:attribute> 
	<xsl:copy-of select="document('../reg/local_reg.xml')"/>
</xsl:element>

<xsl:element name="xsl:variable">
	<xsl:attribute name ="name">OID_file</xsl:attribute> 
	<xsl:copy-of select="document('../reg/OID_reg.xml')"/>
</xsl:element>

<xsl:element name="xsl:variable">
	<xsl:attribute name ="name">short_OID_file</xsl:attribute> 
	<!--xsl:copy-of select="document('../reg/short_OID.xml')"/-->
</xsl:element>

<xsl:element name="xsl:variable">
	<xsl:attribute name ="name">pers_file</xsl:attribute> 
	<xsl:copy-of select="document('../reg/pers_reg.xml')"/>
</xsl:element>


<xsl:copy-of select="document('dllxmlfunc.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('top.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('API.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('common.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('extensions.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('attributes.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('templ_stamp.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('Certificate.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('CertificateList.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('CertificationRequest.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('PKCS7.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('TimeStampReq.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('PKIMessage.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('TimeStampResp.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('OCSPRequest.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('OCSPResponse.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('DVCSRequest.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('DVCSResponse.xsl')/xsl:stylesheet/*"/>
<xsl:copy-of select="document('TimeStampAuthenticodeRequest.xsl')/xsl:stylesheet/*"/>

</xsl:element>
</xsl:template>
</xsl:stylesheet>