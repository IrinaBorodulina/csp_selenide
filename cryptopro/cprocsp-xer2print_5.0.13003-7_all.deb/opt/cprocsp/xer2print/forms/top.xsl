<?xml version="1.0" encoding="windows-1251"?>
 <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
 		xmlns:fo="http://www.w3.org/1999/XSL/Format"
 		version='1.0'>

<!--��塞 ᠬ������ᠭ�� ���䨪��-->
<!--���� ��⠥� �� �� Subject=Issuer � ��������� IssuerAltName, � ⠪�� ��������� cA-->

<xsl:variable name="DNSubject">
  <xsl:apply-templates select="//subject/rdnSequence/RelativeDistinguishedName">
    <xsl:sort select="position()" order="descending" data-type="number"/>
  </xsl:apply-templates>
</xsl:variable>
<xsl:variable name="DNIssuer">
  <xsl:apply-templates select="//issuer/rdnSequence/RelativeDistinguishedName">
    <xsl:sort select="position()" order="descending" data-type="number"/>
  </xsl:apply-templates>
</xsl:variable>

<xsl:variable name="IsSelfSigned">
    <xsl:choose>
      <xsl:when test="$DNSubject=$DNIssuer and count(//cA) &gt; 0 and count(//Extension[extnID = '2.5.29.18']) = 0">1</xsl:when>
      <xsl:otherwise>0</xsl:otherwise>
    </xsl:choose>
</xsl:variable>

<xsl:variable name="Content"></xsl:variable>
<xsl:variable name="pos">1</xsl:variable>
<xsl:variable name="PKI">false</xsl:variable>
<xsl:variable name="Included">true</xsl:variable>

<xsl:template match="/">
  <fo:root>
      <!-- ��ଠ� ������ - �4 -->
    <fo:layout-master-set>
      <fo:simple-page-master master-name="my-page"
	  page-height="279mm" page-width="210mm"
	  margin-top="10mm" margin-bottom="10mm"
	  margin-left="25mm" margin-right="10mm">
	<fo:region-before extent="10mm"/>
	<fo:region-body margin-bottom="{$marginbottom}" margin-top="{$margintop}"/>
	<fo:region-after extent="10mm"/>
      </fo:simple-page-master>
    </fo:layout-master-set>

      <!-- _���� ᠬ ���㬥�� -->
    <fo:page-sequence master-reference="my-page">
      <xsl:apply-templates>
	  <xsl:with-param name="Included">false</xsl:with-param>
      </xsl:apply-templates>
    </fo:page-sequence>
  </fo:root>
</xsl:template>

<xsl:variable name="attributeCount" select="0"/>

</xsl:stylesheet>