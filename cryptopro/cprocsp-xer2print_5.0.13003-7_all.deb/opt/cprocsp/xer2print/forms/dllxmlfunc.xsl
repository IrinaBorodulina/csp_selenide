<?xml version="1.0" encoding="windows-1251"?>
 <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
 		xmlns:fo="http://www.w3.org/1999/XSL/Format"
		xmlns:msxsl="urn:schemas-microsoft-com:xslt"
 		version='1.0'>

<xsl:template name="printOID">
	<xsl:variable name="ID" select="."/>
        <xsl:variable name="result" select="msxsl:node-set($OID_file)/*/*[@id = $ID]/*[name()=$lang]"/>
	<xsl:choose>
		<xsl:when test="string-length($result) != 0">
			<xsl:value-of select="$result"/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select="."/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>


<xsl:template name="Short_printOID">
	<xsl:variable name="ID" select="."/>
        <xsl:variable name="result" select="msxsl:node-set($short_OID_file)/*/*[@id = $ID]/*[name()=$lang]"/>
	<xsl:choose>
		<xsl:when test="string-length($result) != 0">
			<xsl:value-of select="$result"/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select="."/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name="printTEXT">
	<xsl:param name="textID"/>
        <xsl:variable name="result" select="msxsl:node-set($local_file)/*/*[@id = $textID]/*[name()=$lang]"/>
	<xsl:choose>
		<xsl:when test="string-length($result) != 0">
			<xsl:value-of select="$result"/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select="$textID"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name="printPERS">
	<xsl:param name="persID"/>
        <xsl:variable name="result" select="msxsl:node-set($pers_file)/*/*[@id = $persID]/*[name()=$lang]"/>
	<xsl:choose>
		<xsl:when test="string-length($result) != 0">
			<xsl:value-of select="$result"/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select="$persID"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>
</xsl:stylesheet>